#ifndef __HELLO
#define __HELO

int add(int x, int y);
int sub(int x, int y);

#endif
