This example will help you understand how to compile multiple program
files and link them into one executable. The main program is called
hello.c and the other files are: hello.h, file1.c & file2.c. 

Makefile is provided with discriptions to be usesd as a template for
other programs.


