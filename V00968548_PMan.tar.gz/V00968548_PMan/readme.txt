PMan
========================================

How to compile and execute:
------------------------------------------------------------------------------------
1. Navigate to the V00968548_PMan directory in the console
2. Type "make" into the console to compile PMan
3. Check that the PMan executable has been created in the V00968548_PMan directory
4. Type "./PMan" into the console to execute PMan